//
//  addMovieDelegate.swift
//  Filmify
//
//  Created by Jordan Robert Rhodes on 5/28/17.
//  Copyright © 2017 Jordan Robert Rhodes. All rights reserved.
//

import Foundation

protocol addMovieDelegate {
    func plusButtonPressed()
}
