//
//  customClass.swift
//  Filmify
//
//  Created by Jordan Robert Rhodes on 5/31/17.
//  Copyright © 2017 Jordan Robert Rhodes. All rights reserved.
//

import Foundation

class film: NSDictionary {
    var title: String?
    var releaseDate: String?
    var posterPath: String?
    var synopsis: String?
    
    
}
